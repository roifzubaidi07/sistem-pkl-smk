<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Mentor;
use App\Models\Student;
use App\Http\Controllers\Controller;

class PrController extends Controller
{
    
}
