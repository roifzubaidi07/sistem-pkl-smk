

<?php $__env->startSection('nama', Auth::user()->nama); ?>
<?php $__env->startSection('status', Auth::user()->level->nama); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
  <?php if(session('status')): ?>
      <div class="alert alert-success mt-3">
          <?php echo e(session('status')); ?>

      </div>
  <?php endif; ?>
  <div class="row">
    <div class="col-md-3">
      <div class="card mt-3" style="width: 16rem;">
        <img src="<?php echo e(url('assets/img/default.png')); ?>" class="card-img-top rounded" alt="Profil">
        <div class="card-body">
          <?php if($user->user->level_id == 5 && $user->user->level_id != null): ?>
          <h5 class="card-title"><?php echo e($user->user->nama); ?></h5>
          <h6 class="card-subtitle mb-2 text-muted">Kelas: <?php echo e($user->grade->nama); ?></h6>
          <h6 class="card-subtitle mb-2 text-muted">Guru Pembimbing: <?php echo e($user->mentor ? $user->mentor->user->nama : "-"); ?></h6>
          <h6 class="card-subtitle mb-2 text-muted">Tempat DUDI: <?php echo e($user->industry ? $user->industry->nama : "-"); ?></h6>
          <?php else: ?>
          <h5 class="card-title"><?php echo e($user->nama); ?></h5>
          
          <?php endif; ?>
        </div>
      </div>
    </div>
    <div class="col m-3">
      <?php if($user->user->level_id == 5): ?>
      <h4>Daftar Jurnal</h4>
      <div class="card mb-4">
        <div class="card-body">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Tanggal</th>
                        <th>Kegiatan</th>
                        <th>Dokumentasi</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $jurnals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jurnal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($jurnal->waktu); ?></td>
                        <td><?php echo e($jurnal->kegiatan); ?></td>
                        <td>
                            <a class="badge rounded-pill bg-info text-dark text-decoration-none" href="/storage/<?php echo e($jurnal->image); ?>" target="_blank">Lihat dokumentasi</a>
                        </td>
                        <td>
                            <?php if($jurnal->verifikasi === 0): ?>
                                <a class="badge rounded-pill bg-danger text-light text-decoration-none disabled">Belum Terverifikasi</a>
                            <?php else: ?> 
                                <a class="badge rounded-pill bg-success text-light text-decoration-none disabled">Sudah terverifikasi</a>                        
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
      </div>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Kuliah\Skripsi\Sistem\sistem-prakerin\resources\views/admin/pengguna/info.blade.php ENDPATH**/ ?>