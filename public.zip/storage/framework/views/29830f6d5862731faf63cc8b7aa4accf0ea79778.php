
 
<?php $__env->startSection('nama', Auth::user()->nama); ?>
<?php $__env->startSection('status', Auth::user()->level->nama); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <h3 class="mt-4">Daftar DUDI PKL</h3>
    <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>
    <div class="card mb-4">
        <div class="card-body">
            <table id="datatablesSimple" class="table table-striped">
                <thead>
                    <tr>
                        <th>Nama</th>
                        <th>Alamat</th>
                        <th>Kuota</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $industries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $industry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($industry->nama); ?></td>
                        <td><?php echo e($industry->alamat); ?></td>
                        <td><?php echo e($industry->kuota); ?></td>
                        <td>
                            <form action="/dashboard/humas/dudi/<?php echo e($industry->id); ?>">
                            <a href="/dashboard/humas/dudi/<?php echo e($industry->id); ?>/edit" class="badge rounded-pill bg-primary text-white text-decoration-none">Edit</a>
                            <a href="/dashboard/humas/dudi/<?php echo e($industry->id); ?>" class="badge rounded-pill bg-info text-dark text-decoration-none">info</a>
                                <?php echo method_field('delete'); ?>
                                <button type="submit" class="badge rounded-pill bg-danger text-white text-decoration-none">Hapus</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <a href="/dashboard/humas/dudi/create" class="btn btn-primary">Tambah DUDI</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Kuliah\Skripsi\Sistem\sistem-prakerin\resources\views/humas/industries.blade.php ENDPATH**/ ?>