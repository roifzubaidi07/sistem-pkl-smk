
 
<?php $__env->startSection('nama', Auth::user()->nama); ?>
<?php $__env->startSection('status', Auth::user()->level->nama); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <h3 class="mt-4">Daftar Siswa Bimbingan</h3>
    <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>
    <?php $__errorArgs = ['sertifikat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="alert alert-danger">
            <?php echo e($message); ?>

        </div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <div class="card mb-4">
        <div class="card-body">
            <table id="datatablesSimple" class="table table-striped">
                <thead>
                    <tr>
                        <th>Nama</th>
                        <th>NIS</th>
                        <th>Kelas</th>
                        <th>DUDI</th>
                        <th>Sertifikat</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($student->user->nama); ?></td>
                        <td><?php echo e($student->user->no_induk); ?></td>
                        <td><?php echo e($student->grade->nama); ?></td>
                        <td><?php echo e($student->industry ? $student->industry->nama : '-'); ?></td>
                        <?php if($student->sertifikat == null): ?>
                        <td><form action="/dashboard/pembimbing/sertifikat" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>
                            <div class="input-group input-group-sm">
                                <input type="hidden" name="id" value="<?php echo e($student->id); ?>">
                                <input type="file" id="unggah_laporan" class="form-control <?php $__errorArgs = ['sertifikat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="file" name="sertifikat" accept="application/pdf">
                                <button type="submit" class="btn btn-primary">Unggah</button>
                            </div>
                        </form></td>
                        <?php else: ?>
                        <td>
                            <a class="badge rounded-pill bg-success text-light text-decoration-none disabled">File sudah diunggah</a>
                            <a class="badge rounded-pill bg-light text-dark text-decoration-none" href="/storage/<?php echo e($student->sertifikat); ?>" target="_blank">Lihat File</a>
                        </td>
                        <?php endif; ?>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Kuliah\Skripsi\Sistem\sistem-prakerin\resources\views/pembimbing/index.blade.php ENDPATH**/ ?>