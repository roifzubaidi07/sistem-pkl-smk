
 
<?php $__env->startSection('nama', Auth::user()->nama); ?>
<?php $__env->startSection('status', Auth::user()->level->nama); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <h3 class="mt-4">Daftar Siswa PKL</h3>
    <div class="card mb-4">
        <div class="card-body">
            <form action="/dashboard/humas/edit" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('put'); ?>
                <table id="datatablesSimple" class="table table-striped">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>Nama</th>
                            <th>NIS</th>
                            <th>Kelas</th>
                            <th>DUDI</th>
                            <th>Pembimbing</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <input name="id[]" value="<?php echo e($student->id); ?>" hidden>
                            <td><?php echo e($student->id); ?></td>
                            <td><?php echo e($student->user->nama); ?></td>
                            <td><?php echo e($student->user->no_induk); ?></td>
                            <td><?php echo e($student->grade->nama); ?></td>
                            <td><?php echo e($student->industry ? $student->industry->nama : '-'); ?></td>
                            <td>
                                <select class="form-select" aria-label="Default select example" name="mentor_id[]">
                                    <option value="">-</option>
                                    <?php $__currentLoopData = $mentors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mentor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($mentor->major_id == $student->grade->major_id): ?>
                                            <?php if(old('mentor_id', $mentor->id == $student->mentor_id)): ?>
                                                <option value="<?php echo e($mentor->id); ?>" selected><?php echo e($mentor->user->nama); ?></option>
                                            <?php else: ?>
                                                <option value="<?php echo e($mentor->id); ?>"><?php echo e($mentor->user->nama); ?></option>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <button type="submit" class="btn btn-primary align-self-end">Simpan</button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Kuliah\Skripsi\Sistem\sistem-prakerin\resources\views/humas/pembimbing_edit.blade.php ENDPATH**/ ?>