
 
<?php $__env->startSection('nama', Auth::user()->nama); ?>
<?php $__env->startSection('status', Auth::user()->level->nama); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <h3 class="mt-4">Daftar Berkas Pembimbing</h3>
    <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>
    <?php $__errorArgs = ['file_bimbingan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="alert alert-danger">
            <?php echo e($message); ?>

        </div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <div class="card mb-4">
        <div class="card-body">
            <table id="datatablesSimple" class="table table-striped">
                <thead>
                    <tr>
                        <th>Nama</th>
                        <th>Unduh File</th>
                        <th>Unggah File</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($file->name); ?></td>
                        <td><a class="badge rounded-pill bg-primary text-light text-decoration-none" href="/dashboard/pembimbing/berkas/<?php echo e($file->id); ?>">Unduh</a></td>
                        <?php if($file->is_pembimbing == false): ?>
                            <td>-</td>
                            <td>-</td>
                        <?php else: ?>    
                        <?php if($pembimbing->file_bimbingan === null): ?>
                            <td>
                                <form action="/dashboard/pembimbing/berkas/bimbingan" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('put'); ?>
                                    <div class="input-group input-group-sm">
                                        <input type="file" id="unggah_laporan" class="form-control <?php $__errorArgs = ['file_bimbingan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="file" name="file_bimbingan" accept="application/pdf">
                                        <button type="submit" class="btn btn-primary">Unggah</button>
                                    </div>
                                </form>
                            </td>
                                <?php else: ?>
                            <td>
                                <a class="badge rounded-pill bg-success text-light text-decoration-none disabled">File sudah diunggah</a>
                                <a class="badge rounded-pill bg-light text-dark text-decoration-none" href="\storage\<?php echo e($pembimbing->file_bimbingan); ?>" target="_blank">Lihat File</a>
                            </td>
                        <?php endif; ?>
                        <td>
                            <?php if($pembimbing->file_bimbingan === null): ?>
                            <a class="badge rounded-pill bg-danger text-light text-decoration-none disabled">File Belum Diunggah</a>
                            <?php else: ?>
                            <a class="badge rounded-pill bg-success text-light text-decoration-none disabled">Terunggah</a>
                            <?php endif; ?>
                        </td>
                        <?php endif; ?>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Kuliah\Skripsi\Sistem\sistem-prakerin\resources\views/pembimbing/berkas.blade.php ENDPATH**/ ?>