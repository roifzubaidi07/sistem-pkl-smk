
 
<?php $__env->startSection('nama', Auth::user()->nama); ?>
<?php $__env->startSection('status', Auth::user()->level->nama); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <h3 class="mt-4">Info <?php echo e($industry->nama); ?></h3>
    <div class="row">
        <div class="col-md-7">
            <div class="card" style="">
                <div class="card-body">
                  <h5 class="card-title"><?php echo e($industry->nama); ?></h5>
                  <h6 class="card-subtitle mb-2 text-muted"><?php echo e($industry->alamat); ?> | Kuota: <?php echo e($industry->kuota); ?></h6>
                  <p class="card-text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Porro, repellendus! Facere consequatur, laudantium numquam nobis illo animi inventore? Aspernatur dignissimos consectetur obcaecati! Ipsam dolor accusamus illo voluptatem dolorem inventore quasi.</p>
                  <a href="/dashboard/humas/dudi" class="card-link">Kembali</a>
                </div>
              </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Kuliah\Skripsi\Sistem\sistem-prakerin\resources\views/humas/dudi/show.blade.php ENDPATH**/ ?>