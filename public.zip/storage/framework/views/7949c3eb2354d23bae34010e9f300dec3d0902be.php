

<?php $__env->startSection('nama', Auth::user()->nama); ?>
<?php $__env->startSection('status', Auth::user()->level->nama); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
  <?php if(session('status')): ?>
      <div class="alert alert-success mt-3">
          <?php echo e(session('status')); ?>

      </div>
  <?php endif; ?>
  <div class="row">
    <div class="col-md-3">
      <div class="card mt-3" style="width: 16rem;">
        <img src="<?php echo e(url('assets/img/default.png')); ?>" class="card-img-top rounded" alt="Profil">
        <div class="card-body">
          <h5 class="card-title"><?php echo e($student->user->nama); ?></h5>
          <h6 class="card-subtitle mb-2 text-muted">Kelas: <?php echo e($student->grade->nama); ?></h6>
          <h6 class="card-subtitle mb-2 text-muted">Guru Pembimbing: <?php echo e($student->mentor ? $student->mentor->user->nama : "-"); ?></h6>
          <h6 class="card-subtitle mb-2 text-muted">Tempat DUDI: <?php echo e($student->industry ? $student->industry->nama : "-"); ?></h6>
        </div>
      </div>
    </div>
    <div class="col m-3">
      <h3>Selamat Datang, <?php echo e(Auth::user()->nama); ?></h3>
      <div class="card mb-3">
        <div class="card-body">
          <p class="mb-0">
              Selamat Datang di sistem informasi PKL SMK Negeri 1 Sumenep. Pada sistem ini Anda dapat melakukan pengelolaan data PKL. Segala kegiatan PKL di SMK Negeri 1 Sumenep diintegrasikan dalam sistem ini untuk memudahkan Anda dalam melaksanakan kegiatan PKL.
          </p>
        </div>
      </div>
      <?php if($industrySubmission == null): ?>
      <div class="card">
        <div class="card-header">
          Informasi DUDI PKL
        </div>
        <div class="card-body">
          <blockquote class="blockquote mb-0">
            <p>Anda dialokasikan ke DUDI <?php echo e($student->industry ? $student->industry->nama : "-"); ?>, Anda dapat mengajukan DUDI sendiri dengan menekan tombol "Ajukan DUDI"
            </p>
            <a href="/dashboard/siswa/dudi/create" class="btn btn-primary">Ajukan DUDI</a>
          </blockquote>
        </div>
      </div>
      <?php else: ?>
      <div class="card">
        <div class="card-header">
          Informasi DUDI PKL
        </div>
        <div class="card-body">
          <blockquote class="blockquote mb-0">
            <p>Anda mengajukan DUDI <?php echo e($industrySubmission->nama); ?>, status verifikasi Anda saat ini adalah <?php if($industrySubmission->verifikasi == 0): ?> <b style="color: red">menunggu persetujuan kakomli </b> <?php else: ?> <b style="color: green"> diterima </b><?php endif; ?>
            </p>
          </blockquote>
        </div>
      </div>
      <?php endif; ?>
      <?php if($student->sertifikat != null): ?>
      <div class="card mt-3">
        <div class="card-header">
          Sertifikat PKL
        </div>
        <div class="card-body">
          <blockquote class="blockquote mb-0">
            <p>Anda dapat mengakses sertifikat PKL Anda <a class="d-inline" href="\storage\<?php echo e($student->sertifikat); ?>" target="_blank">disini</a>
            </p>
          </blockquote>
        </div>
      </div>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Kuliah\Skripsi\Sistem\sistem-prakerin\resources\views/siswa/index.blade.php ENDPATH**/ ?>