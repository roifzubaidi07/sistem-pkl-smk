
 
<?php $__env->startSection('nama', Auth::user()->nama); ?>
<?php $__env->startSection('status', Auth::user()->level->nama); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <h3 class="mt-4">Daftar Siswa PKL</h3>
    <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>
    <div class="card-body">
        <p class="mb-0">
            Halaman ini adalah halaman untuk menampilkan daftar siswa. Dalam halaman ini, Anda akan disajikan tabel daftar siswa yang sedang melaksanakan PKL beserta informasi DUDI dan guru pembimbing dari masing-masing siswa.
        </p>
    </div>
    <div class="card mb-4">
        <div class="card-body">
            <table id="datatablesSimple" class="table table-striped">
                <thead>
                    <tr>
                        <th>Nama</th>
                        <th>NIS</th>
                        <th>Kelas</th>
                        <th>Jurusan</th>
                        <th>DUDI</th>
                        <th>Pembimbing</th>
                        <th>Laporan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($student->user->nama); ?></td>
                        <td><?php echo e($student->user->no_induk); ?></td>
                        <td><?php echo e($student->grade->nama); ?></td>
                        <td><?php echo e($student->grade->major->nama); ?></td>
                        <td><?php echo e($student->industry ? $student->industry->nama : '-'); ?></td>
                        <td><?php echo e($student->mentor ? $student->mentor->user->nama : '-'); ?></td>
                        <?php if($student->file_laporan != null): ?>
                        <td><a class="badge rounded-pill bg-primary text-light text-decoration-none d-inline" href="\storage\<?php echo e($student->file_laporan); ?>" target="_blank">Lihat Laporan</a></td>
                        <?php else: ?>
                        <td>-</td>
                        <?php endif; ?>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <a href="/dashboard/humas/edit" class="btn btn-primary align-self-end">Edit Pembimbing</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Kuliah\Skripsi\Sistem\sistem-prakerin\resources\views/humas/index.blade.php ENDPATH**/ ?>