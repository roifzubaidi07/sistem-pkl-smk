
 
<?php $__env->startSection('nama', Auth::user()->nama); ?>
<?php $__env->startSection('status', Auth::user()->level->nama); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <h1 class="mt-4">Dashboard</h1>

    <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>
    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-table me-1"></i>
            Daftar Pengguna Sistem
        </div>
        <div class="card-body">
            <table id="datatablesSimple">
                <thead>
                    <tr>
                        <th>Nama</th>
                        <th>No Induk</th>
                        <th>No Telfon</th>
                        <th>Alamat</th>
                        <th>Level Pengguna</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($user->nama); ?></td>
                        <td><?php echo e($user->no_induk); ?></td>
                        <td><?php echo e($user->no_telp); ?></td>
                        <td><?php echo e($user->alamat); ?></td>
                        <td><?php echo e($user->level->nama); ?></td>
                        <td>
                            <a class="badge rounded-pill bg-success text-light text-decoration-none" href="/dashboard/admin/pengguna/<?php echo e($user->id); ?>/edit">Edit</a>
                            <?php if($user->level_id != 1): ?>
                                <form action="/dashboard/admin/pengguna/<?php echo e($user->id); ?>" method="post" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <button type="submit" class="badge rounded-pill bg-danger text-white text-decoration-none border-0" onclick="return confirm(`Apakah Anda yakin ingin menghapus <?php echo e($user->nama); ?> dari database ?`)">Hapus</button>
                                </form>
                            <?php endif; ?>
                            </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <a href="/dashboard/admin/pengguna/create" class="btn btn-primary">Tambah Pengguna</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Kuliah\Skripsi\Sistem\sistem-prakerin\resources\views/admin/index.blade.php ENDPATH**/ ?>