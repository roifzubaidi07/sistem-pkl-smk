
 
<?php $__env->startSection('nama', Auth::user()->nama); ?>
<?php $__env->startSection('status', Auth::user()->level->nama.' ('.strtoupper(Auth::user()->chief[0]->major->abbr).')'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <h3 class="mt-4">Penempatan PKL 
        <h5> Nama DUDI: 
                <?php echo e($dudi->nama); ?>

        </h5>
    </h3>
    <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>
    <div class="card mb-4">
        <div class="card-body">
            <table id="datatablesSimple" class="table table-striped">
                <thead>
                    <tr>
                        <th>Nama</th>
                        <th>NIS</th>
                        <th>Kelas</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($student->user->nama); ?></td>
                            <td><?php echo e($student->user->no_induk); ?></td>
                            <td><?php echo e($student->grade->nama); ?></td>
                            <td>
                                <?php if(Auth::user()->chief[0]->major->abbr == $student->grade->major->abbr): ?>
                                <form action="/dashboard/kakomli/dudi/<?php echo e($student->id); ?>" method="post" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <input type="text" name="industry_id" value="<?php echo e($dudi->id); ?>" hidden>
                                    <button type="submit" class="badge rounded-pill bg-danger text-white text-decoration-none border-0" onclick="return confirm(`Apakah Anda yakin ingin menghapus <?php echo e($student->user->nama); ?> dari DUDI <?php echo e($dudi->nama); ?> ?`)">Hapus</button>
                                </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php if($dudi->kuota != null): ?>
            <a href="/dashboard/kakomli/dudi/<?php echo e($dudi->id); ?>/tambah" class="btn btn-primary">Tambah Siswa</a>
            <?php endif; ?>
            <a href="/dashboard/kakomli" class="btn btn-link">Kembali</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Kuliah\Skripsi\Sistem\sistem-prakerin\resources\views/kakomli/siswa/index.blade.php ENDPATH**/ ?>