
 
<?php $__env->startSection('nama', Auth::user()->nama); ?>
<?php $__env->startSection('status', Auth::user()->level->nama.' ('.strtoupper(Auth::user()->chief[0]->major->abbr).')'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <h3 class="mt-4">Penempatan PKL
        <h5> Nama DUDI: 
                <?php echo e($dudi->nama); ?>

        </h5>
        <h5> Kuota: 
            <p id="kuota" class="d-inline"><?php echo e(app\Http\Controllers\Controller::cekKuota($dudi->id)); ?></p>/<?php echo e($dudi->kuota); ?>

        </h5>
    </h3>
    <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <?php echo e($errors->first()); ?>

        </div>
    <?php endif; ?>
    <div class="card mb-4">
        <div class="card-body">
            <form action="/dashboard/kakomli/dudi/<?php echo e($dudi->id); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>
            <table id="datatablesSimple" class="table table-striped">
                <thead>
                    <tr>
                        <th>Nama</th>
                        <th>NIS</th>
                        <th>Kelas</th>
                        <th>Tambah Siswa</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <input type="text" name="industry_id" value="<?php echo e($dudi->id); ?>" hidden>
                            <input type="text" name="jumlah" value="<?php echo e(app\Http\Controllers\Controller::cekKuota($dudi->id)); ?>" hidden>
                            <input type="text" name="kuota" value="<?php echo e($dudi->kuota); ?>" hidden>
                            <td><?php echo e($student->user->nama); ?></td>
                            <td><?php echo e($student->user->no_induk); ?></td>
                            <td><?php echo e($student->grade->nama); ?></td>
                            <td>
                                <div>
                                    <input class="form-check-input" type="checkbox" id="checkboxNoLabel" name="id[]" value="<?php echo e($student->id); ?>" onchange="kuota()">
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <button type="submit" class="btn btn-primary">Simpan Siswa</button>
            </form>
        </div>
    </div>
</div>

<script>
    
    var kuota_awal = <?php echo e(app\Http\Controllers\Controller::cekKuota($dudi->id)); ?>

    var kuota_temp = kuota_awal;
    function kuota(){
        // if (document.getElementById("checkboxNoLabel").checked == true){
        //     kuota_temp += 1;
        //     document.getElementById("kuota").innerHTML = kuota_temp;
        // } else{
        //     kuota_temp -= 1;
        //     document.getElementById("kuota").innerHTML = kuota_temp;
        // }
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Kuliah\Skripsi\Sistem\sistem-prakerin\resources\views/kakomli/siswa/add.blade.php ENDPATH**/ ?>