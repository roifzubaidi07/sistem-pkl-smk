
 
<?php $__env->startSection('nama', Auth::user()->nama); ?>
<?php $__env->startSection('status', Auth::user()->level->nama.' ('.strtoupper(Auth::user()->chief[0]->major->abbr).')'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <h3 class="mt-4">Daftar DUDI PKL</h3>
    <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>
    <div class="card mb-4">
        <div class="card-body">
            <table id="datatablesSimple" class="table table-striped">
                <thead>
                    <tr>
                        <th>Nama</th>
                        <th>Alamat</th>
                        <th>Kuota</th>
                        <th>Info</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $industries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $industry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($industry->nama); ?></td>
                        <td><?php echo e($industry->alamat); ?></td>
                        <?php if($industry->kuota != null): ?>
                        <td><?php echo e(app\Http\Controllers\Controller::cekKuota($industry->id)); ?>/<?php echo e($industry->kuota); ?></td>
                        <?php else: ?>
                        <td>-</td>
                        <?php endif; ?>
                        <td><a class="badge rounded-pill bg-info text-dark text-decoration-none" href="/dashboard/kakomli/dudi/<?php echo e($industry->id); ?>">Info</a></td>
                    </tr> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Kuliah\Skripsi\Sistem\sistem-prakerin\resources\views/kakomli/index.blade.php ENDPATH**/ ?>