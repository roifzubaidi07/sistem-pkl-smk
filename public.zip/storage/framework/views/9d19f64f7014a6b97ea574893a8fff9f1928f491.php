
 
<?php $__env->startSection('nama', Auth::user()->nama); ?>
<?php $__env->startSection('status', Auth::user()->level->nama); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <h3 class="mt-4">Daftar Pembimbing PKL</h3>

    
    <div class="card mb-4">
        <div class="card-body">
            <table id="datatablesSimple" class="table table-striped">
                <thead>
                    <tr>
                        <th>Nama</th>
                        <th>NIK</th>
                        <th>Jurusan</th>
                        <th>Laporan Bimbingan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $mentors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mentor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($mentor->user->nama); ?></td>
                        <td><?php echo e($mentor->user->no_induk); ?></td>
                        <td><?php echo e($mentor->major->nama); ?></td>
                        <?php if($mentor->file_bimbingan != null): ?>
                        <td><a class="badge rounded-pill bg-primary text-light text-decoration-none d-inline" href="\storage\<?php echo e($mentor->file_bimbingan); ?>" target="_blank">Lihat Laporan</a></td>
                        <?php else: ?>
                        <td>-</td>
                        <?php endif; ?>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Kuliah\Skripsi\Sistem\sistem-prakerin\resources\views/humas/pembimbing.blade.php ENDPATH**/ ?>