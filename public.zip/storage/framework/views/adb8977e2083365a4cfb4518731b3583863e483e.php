
 
<?php $__env->startSection('nama', "M. Ro'if"); ?>
<?php $__env->startSection('status', 'Guru Pembimbing'); ?>
<?php $__env->startSection('sidebar'); ?>
    <a class="nav-link" href="/mentors">
        <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
        Daftar Siswa
    </a>
    <a class="nav-link" href="/mentors/bimbingan">
        <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
        Bimbingan
    </a>
    <a class="nav-link" href="/mentors/jurnal">
        <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
        Jurnal Harian
    </a>
    <a class="nav-link" href="mentors/absensi">
        <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
        Absensi
    </a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <h1 class="mt-4">Daftar absensi Siswa Bimbingan</h1>

    <div class="card mb-4">
        <div class="card-body">
            <table id="datatablesSimple" class="table table-striped">
                <thead>
                    <tr>
                        <th>Nama</th>
                        <th>Status Datang</th>
                        <th>Status Pulang</th>
                        <th>Verifikasi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $attendences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($attendance->student->user->nama); ?></td>
                        <td><?php echo e($attendance->status_datang); ?></td>
                        <td><?php echo e($attendance->status_pulang); ?></td>
                        <td><a class="badge rounded-pill bg-info text-dark text-decoration-none" href="#">Verifikasi Datang</a>
                        <td><a class="badge rounded-pill bg-info text-dark text-decoration-none" href="#">Verifikasi Pulang</a>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Kuliah\Skripsi\Sistem\sistem-prakerin\resources\views/pembimbing/daftar_absensi.blade.php ENDPATH**/ ?>