
 
<?php $__env->startSection('nama', Auth::user()->nama); ?>
<?php $__env->startSection('status', Auth::user()->level->nama); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <h3 class="mt-4">Daftar Presensi Siswa Bimbingan</h3>
    <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>
    <div class="card mb-4">
        <div class="card-body">
            <table id="datatablesSimple" class="table table-striped">
                <thead>
                    <tr>
                        <th>Nama</th>
                        <th>Tanggal</th>
                        <th>Jam Datang</th>
                        <th>Jam Pulang</th>
                        <th>Status</th>
                        <th>Status Verifikasi</th>
                        <th>Verifikasi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $attendences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($attendance->student->user->nama); ?></td>
                        <td><?php echo e($attendance->tanggal); ?></td>
                        <td><?php echo e($attendance->jam_datang); ?></td>
                        <td><?php echo e($attendance->jam_pulang); ?></td>
                        <td>
                            <?php switch($attendance->status):
                                case (1): ?>
                                    Hadir
                                    <?php break; ?>
                                <?php case (2): ?>
                                    Sakit
                                    <?php break; ?>
                                <?php case (3): ?>
                                    Izin
                                    <?php break; ?>
                                <?php default: ?>
                                    Alpha
                            <?php endswitch; ?>
                        </td>
                        <td>
                        <?php if($attendance->verifikasi === 0): ?>
                            <a class="badge rounded-pill bg-danger text-light text-decoration-none disabled">Belum Terverifikasi</a>
                        <?php else: ?> 
                            <a class="badge rounded-pill bg-success text-light text-decoration-none disabled">Sudah terverifikasi</a>                        
                        <?php endif; ?></td>
                        <td>
                            <?php if($attendance->verifikasi === 0): ?>
                                <form action="/dashboard/pembimbing/presensi/<?php echo e($attendance->id); ?>" method="post">
                                    <?php echo method_field('put'); ?>
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="badge rounded-pill bg-info text-dark text-decoration-none border-0" onclick="return confirm('Apakah Anda yakin ingin melakukan verifikasi ?')" name="1">Verifikasi</button>
                                </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Kuliah\Skripsi\Sistem\sistem-prakerin\resources\views/pembimbing/attendences.blade.php ENDPATH**/ ?>