
 
<?php $__env->startSection('nama', Auth::user()->nama); ?>
<?php $__env->startSection('status', Auth::user()->level->nama.' ('.strtoupper(Auth::user()->chief[0]->major->abbr).')'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <h3 class="mt-4">Daftar Pengajuan DUDI PKL Siswa</h3>
    <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>
    <div class="card mb-4">
        <div class="card-body">
            <table id="datatablesSimple" class="table table-striped">
                <thead>
                    <tr>
                        <th>Nama</th>
                        <th>Alamat</th>
                        <th>Alasan Pengajuan</th>
                        <th>Nama Pengaju</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $submissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($submission->nama); ?></td>
                        <td><?php echo e($submission->alamat); ?></td>
                        <td><?php echo e($submission->alasan); ?></td>
                        <td><?php echo e($submission->student->user->nama); ?></td>
                        <?php if($submission->verifikasi == 0): ?>
                        <td><form action="/dashboard/kakomli/pendataan/<?php echo e($submission->id); ?>" method="post" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>
                            <button type="submit" class="badge rounded-pill bg-success text-white text-decoration-none border-0" onclick="return confirm(`Apakah Anda yakin ingin memverifikasi data pengajuan dari siswa <?php echo e($submission->student->user->nama); ?> ?`)">Verifikasi</button>
                        </form>
                        <form action="/dashboard/kakomli/pendataan/<?php echo e($submission->id); ?>" method="post" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>
                            <button type="submit" class="badge rounded-pill bg-danger text-white text-decoration-none border-0" onclick="return confirm(`Apakah Anda yakin ingin menghapus data pengajuan dari siswa <?php echo e($submission->student->user->nama); ?> ?`)">Hapus</button>
                        </form></td>
                        <?php else: ?>
                        <td><a class="badge rounded-pill bg-success text-white text-decoration-none disabled" >Terverifikasi</a></td>
                        <?php endif; ?>
                    </tr> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Kuliah\Skripsi\Sistem\sistem-prakerin\resources\views/kakomli/pengajuan/index.blade.php ENDPATH**/ ?>