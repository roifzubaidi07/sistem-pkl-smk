
 
<?php $__env->startSection('nama', "M. Ro'if"); ?>
<?php $__env->startSection('status', 'Admin'); ?>
<?php if(@section('status', 'Admin') == true): ?>
<?php $__env->startSection('sidebar'); ?>
    <a class="nav-link" href="index.blade.php">
        <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
        Pengguna
    </a>
<?php $__env->stopSection(); ?>
<?php endif; ?>
<?php echo $__env->make('Template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Kuliah\Skripsi\Sistem\sistem-prakerin\resources\views/index.blade.php ENDPATH**/ ?>