
 
<?php $__env->startSection('nama', Auth::user()->nama); ?>
<?php $__env->startSection('status', Auth::user()->level->nama); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <h3 class="mt-4">Daftar Jurnal 
        <h5> Nama Siswa : 
            <?php echo e($student->user->nama); ?>

        </h5>
    </h3>
    <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>
    <div class="card mb-4">
        <div class="card-body">
            <table id="datatablesSimple" class="table table-striped">
                <thead>
                    <tr>
                        <th>Tanggal</th>
                        <th>Kegiatan</th>
                        <th>Dokumentasi</th>
                        <th>Status</th>
                        <th>Verifikasi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $jurnals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jurnal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($jurnal->waktu); ?></td>
                        <td><?php echo e($jurnal->kegiatan); ?></td>
                        <td>
                            <a class="badge rounded-pill bg-info text-dark text-decoration-none" href="/storage/<?php echo e($jurnal->image); ?>" target="_blank">Lihat dokumentasi</a>
                        </td>
                        <td>
                            <?php if($jurnal->verifikasi === 0): ?>
                                <a class="badge rounded-pill bg-danger text-light text-decoration-none disabled">Belum Terverifikasi</a>
                            <?php else: ?> 
                                <a class="badge rounded-pill bg-success text-light text-decoration-none disabled">Sudah terverifikasi</a>                        
                            <?php endif; ?>
                        </td>
                            <td>
                                <?php if($jurnal->verifikasi === 0): ?>
                                    <form action="/dashboard/pembimbing/jurnal/<?php echo e($jurnal->id); ?>" method="post">
                                        <?php echo method_field('put'); ?>
                                        <?php echo csrf_field(); ?>
                                        <input type="text" name="student_id" value="<?php echo e($jurnal->student_id); ?>" hidden>
                                        <button type="submit" class="badge rounded-pill bg-info text-dark text-decoration-none border-0" onclick="return confirm('Apakah Anda yakin ingin melakukan verifikasi ?')" name="1">Verifikasi</button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Kuliah\Skripsi\Sistem\sistem-prakerin\resources\views/pembimbing/jurnal.blade.php ENDPATH**/ ?>